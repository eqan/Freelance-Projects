class MemberCreation{
    constructor(name,birth){
        this.name = name
        this.birth = birth
    }
}
module.exports = MemberCreation