export default class Member{
    constructor(name,membertype,datejoined,birth,points){
        this.name = name
        this.membertype = membertype
        this.datejoined = datejoined
        this.birth = birth
        this.points = points
    }
}